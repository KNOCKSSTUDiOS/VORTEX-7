========================================================
VORTEX 7 / TEMPEST VORTEX MULTI-PLATFORM ICON PACKAGE
KNOCKSSTUDiOS // HOLLYWOOD MOTiON PiCTURES
========================================================

1. UNITY 3D / UNREAL ENGINE:
   - In Unity: Project Settings -> Player -> Icon -> Default Icon
   - Drag 'unity/Vortex7_Master_1024.png' into the slot.
   - For standalone Android/iOS targets, assign 512, 256, 128 into the override slots.

2. APPLE (iOS / iPadOS / macOS / App Store):
   - In Xcode: Assets.xcassets -> AppIcon
   - 1024x1024: 'apple/AppIcon-1024x1024.png' (App Store marketing icon)
   - 180x180: 'apple/AppIcon-180x180.png' (iPhone 3x)
   - 167x167: 'apple/AppIcon-167x167.png' (iPad Pro)

3. ANDROID / TABLETS (Google Play / Samsung / Termux):
   - Place folders in 'android/res/' (mipmap-mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi).
   - Adaptive icon foreground: 'android/ic_launcher_adaptive_foreground.png'.

4. MICROSOFT WINDOWS / STORE / UWP:
   - Package.appxmanifest -> Visual Assets -> Square44, Square71, Square150, Square310, Wide310.

5. AWS / CLOUD DEPLOYMENT & WEB PWA:
   - Upload 'web_pwa/' folder contents to your S3 bucket / CloudFront root / Amplify public dir.
